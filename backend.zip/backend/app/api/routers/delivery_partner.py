from typing import Annotated
from fastapi import APIRouter, Depends, HTTPException,status
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.security.oauth2 import OAuth2PasswordBearer

from app.database.models import DeliveryPartner

from app.services.deliver_partner import DeliverPartnerService

from ..schemas import delivery_partner
from app.api.dependencies import DeliverPartnerServiceDep, get_delivery_partner_access_token,DeliveryPartnerDep

from app.core.security import oauth2_scheme_delivery_partner
from app.utils import decode_access_token

from app.database.redis import is_jti_blacklisted,add_jti_to_blacklist


router=APIRouter(prefix="/delivery_partner",tags=["Delivery Partner"])


@router.post("signup/",response_model=delivery_partner.DeliveryPartnerRead)
async def register_delivery_partner(request:delivery_partner.DeliveryPartnerCreate,   # this is how we get the request
                            service:DeliverPartnerServiceDep
                    ):

    return await service.add(request)

#Login the delivery partner
@router.post("/token")
async def login_delivery_partner(
    request_form:Annotated[OAuth2PasswordRequestForm,Depends()],
    service:DeliverPartnerServiceDep
):
    
    email = request_form.username
    password=request_form.password

    token= await service.token(email,password)

    return {
        "access_token": token,
        "type":"jwt"
    }


### Logout the user
@router.get("/logout")
async def logout_delivery_partner(
    token_data:Annotated[dict,Depends(get_delivery_partner_access_token)],      # now as we have token, now we can take the token and then add it to our blacklist
):
    jti_access_token=token_data["jti"]
    await add_jti_to_blacklist(jti=jti_access_token)

    return { "detail " : " successfully Logged out"}
    


# update the delivery partner
@router.post('/update',response_model=delivery_partner.DeliveryPartnerRead)
async def update_delivery_partner(
    partner_update:delivery_partner.DeliveryPartnerUpdate,
    partner : DeliveryPartnerDep,
    service : DeliverPartnerServiceDep ,
):
    return await service.update(
                    partner.sqlmodel_update(partner_update)
                    )
    

@router.post("/testToken")
async def login__delivery_partner(request,service:DeliverPartnerServiceDep):
     ans= await service.token("root@root.root","root")
     return ans



# @router.get("/dashboard")
# async def get_dashboard(
#     token : Annotated[str,Depends(oauth2_scheme_delivery_partner)],
#     session: SessionDep
# ):
#     data  =  decode_access_token(token=token)

#     if data is None:
#         raise HTTPException(
#             status_code=status.HTTP_401_UNAUTHORIZED,
#             detail="Invalid access token"
#         )

#     print(data , "#################    Data #################3")
    
#     seller = await session.get(Seller,data["user"]["id"])
#     return seller