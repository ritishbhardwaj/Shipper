class Solution:
    def scoreBalance(self, s: str) -> bool:

        summ=0
        for i in s:
            print(abs((ord("a")-ord(i))+1) ,"++++++++++++++")
            summ+=abs((ord("a")-ord(i))+1)

        print(summ)
        if summ%2!=0:
            return False

        target= summ//2
        
        print(target)
        temp1=0
        li=0
        for i in range(len(s)):

            temp1+=abs(((ord("a")-ord(s[i])))+1)
            if temp1==target:
                li=i
                break

        print(li,"======li")
        temp2=0
        for i in range(li+1,len(s)):
            print(i,"---------i")
            temp2+=abs((ord("a")-ord(s[i]))+1)

        print(temp1,temp2)

        if temp1==temp2:
            return True

        return False

obj=Solution()
print(obj.scoreBalance(s ="adcb"))