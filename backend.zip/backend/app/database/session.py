from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from sqlmodel import SQLModel
from typing import Annotated

from app.config import db_settings

# Create a database engine to connect with database
engine = create_async_engine(
    # database type/dialect and file name
    # url=settings.POSTGRES_URL,
    url=db_settings.SQLITE_URL,
    # Log sql queries
    echo=True,
)
 

async def create_db_tables():
    async with engine.begin() as connection:
        from app.database.models import Shipment  # noqa: F401
        await connection.run_sync(SQLModel.metadata.create_all)


async def get_session():
    async_session = sessionmaker(
        bind=engine, class_=AsyncSession, expire_on_commit=False,
    )

    async with async_session() as session:
        yield session





# this is a synchronous version of get_session for use in sync code
'''
def get_db():
    session=sessionmaker(autocommit=False, autoflush=False, bind=engine)
    db=session()
    try:
        yield db
    finally:
        db.close()

async def get_db_async():
    session = sessionmaker(autocommit=False, autoflush=False, bind=engine, class_=AsyncSession)
    async with session() as db:
        yield db



'''