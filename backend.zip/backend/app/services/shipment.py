from datetime import datetime, timedelta
from uuid import UUID

from fastapi import HTTPException,status
from sqlalchemy.ext.asyncio import AsyncSession

# from app.api.dependencies import SellerDep
from app.api.schemas.shipment import ShipmentCreate,ShipmentUpdate
from app.database.models import DeliveryPartner, Seller, Shipment, ShipmentStatus
from app.services.shipment_event import ShipmentEventService

from .base import BaseService
from .deliver_partner import DeliverPartnerService


class ShipmentService(BaseService):
    def __init__(self, session: AsyncSession, delivery_partner:DeliverPartnerService, event_service:ShipmentEventService):
        # Get database session to perform database operations
        super().__init__(Shipment,session)
        self.delivery_partner_service= delivery_partner
        self.event_service=  event_service

    # Get a shipment by id 
    async def get(self, id: UUID) -> Shipment :
        shipment = await self._get(id)
        if shipment is None:
            raise ValueError(f"Shipment with id {id} not found")
        return shipment

    # Add a new shipment
    async def add(self, shipment_create: ShipmentCreate, seller:Seller) -> Shipment:
        new_shipment:Shipment = Shipment(
            **shipment_create.model_dump(),
            status=ShipmentStatus.placed,
            estimated_delivery=datetime.now() + timedelta(days=3),
            seller_id=seller.id,
        )
        # new_shipment.destination
        partner = await self.delivery_partner_service.assign_shipment(new_shipment)
        new_shipment.delivery_partner_id=partner.id

        shipment  = await self._add(new_shipment)

        #adding shipment service
        await self.event_service.add(
            shipment=shipment,
            location = seller.zip_code,
            shipment_status=ShipmentStatus.placed,
            description=f"assigned to delivery partner - {partner.name}"
        )

        return shipment

    # Update an existing shipment
    async def update(self, id: UUID, shipment_update: ShipmentUpdate ,partner :DeliveryPartner) -> Shipment:
        
        shipment :Shipment  = await self.get(id)
        
        if shipment.delivery_partner_id!=partner.id :
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail = "Not Authorised"
            )
        
        updated_data =  shipment_update.model_dump(exclude_none=True)
        
        if shipment_update.estimated_delivery !=None :
            shipment.estimated_delivery=shipment_update.estimated_delivery
           
        if len(updated_data) >1  or not updated_data.estimated_delivery:
            await self.event_service.add(
                shipment=shipment,
                **updated_data
            )
        
        # shipment.sqlmodel_update(shipment_update)

        shipment = await self._update(shipment)

        return shipment

    # Delete a shipment
    async def delete(self, id: UUID) -> None:
        await self._delete(await self.get(id))