from uuid import UUID
from fastapi import APIRouter, HTTPException, status

from app.api.dependencies import ServiceDep
from app.api.schemas.shipment import ShipmentCreate, ShipmentRead, ShipmentUpdate
from app.api.dependencies import SellerDep,DeliverPartnerServiceDep,DeliveryPartnerDep

# api router to group endpoints
router = APIRouter(prefix="/shipment", tags=["Shipment"])


### Read a shipment by id
@router.get("/", response_model=ShipmentRead)
async def get_shipment(id: UUID,
                        service: ServiceDep,
                       _: SellerDep):    # underscore for this dependency is just a industry convention
    # Check for shipment with given id
    shipment = await service.get(id=id)

    if shipment is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Given id doesn't exist!",
        )

    return shipment


### Create a new shipment with content and weight
@router.post("/", response_model=ShipmentRead)
async def submit_shipment(
    shipment: ShipmentCreate,
    service: ServiceDep,
    delivery_partner: DeliverPartnerServiceDep,
    seller:SellerDep
):
    return await service.add(shipment,seller)
    # return await service.add(shipment,)


### Update fields of a shipment
@router.patch("/", response_model=ShipmentRead)
async def update_shipment(
    id: UUID,
    shipment_update: ShipmentUpdate,
    delivery_partner: DeliveryPartnerDep,
    service: ServiceDep,
):
    # Update data with given fields
    update = shipment_update.model_dump(exclude_none=True)

    if not update:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No data provided to update",
        )

    return await service.update(id, update , delivery_partner)


### Delete a shipment by id
@router.delete("/")
async def delete_shipment(id: UUID, service: ServiceDep) -> dict[str, str]:
    # Remove from database
    await service.delete(id)

    return {"detail": f"Shipment with id #{id} is deleted!"}
