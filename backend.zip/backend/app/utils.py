from datetime import datetime, timedelta, timezone
import jwt
from app.database.models import Seller
from app.config import security_settings
from fastapi import HTTPException

from uuid import uuid4

def generate_access_token(
        data:dict,
        expiry:timedelta = timedelta(seconds=15)
)->str :
    return jwt.encode(
            payload={
                **data,
                "jti":str(uuid4()),
                "exp": datetime.now(timezone.utc) + expiry
            },
            algorithm=security_settings.JWT_ALGORITHM,
            key=security_settings.JWT_SECRET
        )


def decode_access_token(token :str)->dict:    # this decoding will return me the dictionary or data as dict
    try:
        return jwt.decode(
                jwt=token,
                key=security_settings.JWT_SECRET,
                algorithms=[security_settings.JWT_ALGORITHM]
                )
    
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=401,
            detail="Expired Token"
        )

    except jwt.PyJWTError as e:
        return { " Decoding JWT error occurs " : f"{e}"}