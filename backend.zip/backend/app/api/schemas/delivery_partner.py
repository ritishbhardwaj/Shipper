from pydantic import BaseModel, EmailStr, Field
from uuid import UUID


class DeliveryPartnerBase(BaseModel):
    name: str
    email: EmailStr
    serviceable_zip_codes:list[int]
    max_handling_capacity:int
    # password: str

class DeliveryPartnerUpdate(DeliveryPartnerBase):
    serviceable_zip_codes:list[int]
    max_handling_capacity:int | None =Field(default=None)


class DeliveryPartnerCreate(DeliveryPartnerBase):
    password:str
    class Config:
        from_attributes = True  

class DeliveryPartnerRead(DeliveryPartnerBase):
    id: UUID
    class Config:
        from_attributes = True