from pydantic import BaseModel, EmailStr
from uuid import UUID


class SellerBase(BaseModel):
    name: str
    email: EmailStr
    # password: str

class SellerCreate(SellerBase):
    password:str
    class Config:
        from_attributes = True  

class SellerRead(SellerBase):
    id: UUID
    class Config:
        from_attributes = True