

from app.services.base import BaseService
from app.database.models import Shipment, ShipmentEvent, ShipmentStatus

class ShipmentEventService(BaseService):
    def __init__(self, session):
        super().__init__( ShipmentEvent , session)

    async def add(
            self,
            shipment:Shipment,
            location:int =None,
            shipment_status:ShipmentStatus=None,
            description:str=None
    ):
        # if location==None:
        #     last_event=await self.get_latest_event(shipment)
        #     shipment_status = last_event.status
        
        # if shipment_status==None:
        #     last_event=await self.get_latest_event(shipment)
        #     location = last_event.location

        if not location or not shipment_status :
            last_event = await self.get_latest_event(shipment)

            location = location if location else last_event.location
            shipment_status = shipment_status if shipment_status else last_event.status
            
            
        new_event = ShipmentEvent(
             location=location,
             status=shipment_status,
             description=description if description else self._get_description(shipment_status,location),
             shipment_id = shipment.id
        )
        return await self._add(new_event)

    async def get_latest_event(self,shipment:Shipment):
        timeline:list = shipment.timeline
        timeline.sort(key=lambda item :item.created_at)
        return timeline[-1]
    
    def _get_description(self,status:ShipmentStatus ,location : int ):
        #here we are using the cases
        match status :
            case ShipmentStatus.placed:
                return "assigned delivery partner"
            case ShipmentStatus.delivered:
                return "successfully delivered"
            case ShipmentStatus.out_for_delivery:
                return "shipment out for delivery "
            case _:
                return f"scanned at {location}"