from pydantic_settings import BaseSettings, SettingsConfigDict


class DatabaseSettings(BaseSettings):
    POSTGRES_SERVER: str
    POSTGRES_PORT: int
    POSTGRES_USER: str
    POSTGRES_PASSWORD: str
    POSTGRES_DB: str

    REDIS_PORT:int
    REDIS_HOST:str

    model_config = SettingsConfigDict(
        env_file="./.env",
        env_ignore_empty=True,
        extra="ignore",
    ) # load variables from .env file

    # Construct the database URL , which is the connection string and used by SQLAlchemy everywhere in the app
    @property
    def POSTGRES_URL(self):
        return f"postgresql+asyncpg://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}@{self.POSTGRES_SERVER}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
    
    @property
    def SQLITE_URL(self):
        return 'sqlite+aiosqlite:///./shipper.db'


class SecuritySettings(BaseSettings):
    JWT_SECRET:str
    JWT_ALGORITHM:str

    model_config=SettingsConfigDict(
        env_file="./.env",
        env_ignore_empty=True,
        extra="ignore",        
    )


security_settings=SecuritySettings()

db_settings=DatabaseSettings()