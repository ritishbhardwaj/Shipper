from datetime import timedelta
from fastapi import HTTPException,status

from app.utils import generate_access_token
from .base import BaseService

from sqlalchemy.ext.asyncio import AsyncSession
# from sqlalchemy import select
from sqlmodel import select

from app.database.models import UserModel
from passlib.context import CryptContext


password_context=CryptContext(schemes=["bcrypt"],deprecated="auto")



class UserService(BaseService):
    def __init__(self, model:UserModel ,  session: AsyncSession):
        # Get database session to perform database operations
        self.session = session   
        self.model = model

    async def _add_user(self,data:dict):
        print()
        print(f"data inside the services/user.py of _add_user is ---> {data} \n ")
        user =  self.model(
            **data,
            password_hash=password_context.hash(data["password"])
        )
        print()
        print(f"user is --------<>> {user}\n")
        return await self._add(user)

    async def _get_by_email(self,email) -> UserModel | None :
        print()
        user=await self.session.scalar(
            select(self.model).where(self.model.email==email) 
        )
        print(f" CALL from services/user.py/_get_by_email ---> user is ---> {user} \n")
        return await self.session.scalar(
            select(self.model).where(self.model.email==email) 
        )

    # async def _get_by_id(self,id) -> UserModel | None :
    #     return await self.session.scalar(
    #         select(self.model).where(self.model.email==id) 
    #     )
    
    async def _generate_token(self,mail,password)->str: 
        
        user =  await self._get_by_email(email=mail)
        print(user,"#################################")

        if user is None   or  not password_context.verify(
                                                    password,
                                                    user.password_hash
                                                    ):
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Email or password is incorrect"
            )

        
        # await self.session.get(Seller,mail)

        # Now user is authenticated
        # we will generate a JWT token
        print(f"printing user id from services/user.py/_generate token {user.id}\n")
        token = generate_access_token(
            data={
                "user":{
                    "name": user.name,
                    "id": str(user.id)
                }
            },
            expiry=timedelta(seconds=9000)
        )
        print(token)

        return token

