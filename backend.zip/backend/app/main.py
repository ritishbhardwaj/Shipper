from contextlib import asynccontextmanager

from fastapi import FastAPI
from scalar_fastapi import get_scalar_api_reference
# from scalar_fastapi import get_scalar_api_reference

# from app.api.routers import shipment as shipment_router,seller as seller_router
from app.api.router import master_router
from app.database.session import create_db_tables


@asynccontextmanager
async def lifespan_handler(app: FastAPI):
    await create_db_tables()
    print("✅ Startup complete!")
    yield
    print("🧹 Shutting down...")

app = FastAPI(
    # Server start/stop listener
    lifespan=lifespan_handler,
)

app.include_router(master_router)

# app.include_router(shipment_router.router)
# app.include_router(seller_router.router)


### Scalar API Documentation
@app.get("/scalar", include_in_schema=False)
def get_scalar_docs():
    return get_scalar_api_reference(
        openapi_url=app.openapi_url,
        title="Scalar API",
    )
