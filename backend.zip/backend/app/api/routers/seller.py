from typing import Annotated
from fastapi import APIRouter, Depends, HTTPException,status
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.security.oauth2 import OAuth2PasswordBearer

from app.database.models import Seller

from ..schemas import seller
from app.api.dependencies import ServiceDepSeller, SessionDep,SellerDep, get_seller_access_token

from app.core.security import oauth2_scheme_seller
from app.utils import decode_access_token

from app.database.redis import is_jti_blacklisted,add_jti_to_blacklist

router=APIRouter(prefix="/seller",tags=["seller"])



@router.get("/",response_model=None)
async def get_all_seller(seller:SellerDep):
    
    return "Hello User", seller


@router.post("/signup",response_model=seller.SellerRead)
async def register_seller(request:seller.SellerCreate,   # this is how we get the request
                            service : ServiceDepSeller
                    ):

    return await service.add(request)

#Login the user
@router.post("/token")
async def login_user(
    request_form:Annotated[OAuth2PasswordRequestForm,Depends()],
    service:ServiceDepSeller
):
    
    email = request_form.username
    password=request_form.password

    print()
    print(f"@@@@@@@@@@@@@@@ {email} , {password}")

    token= await service.token(email,password)

    return {
        "access_token": token,
        "type":"jwt"
    }


### Logout the user
@router.get("/logout")
async def logout_user(
    token_data:Annotated[dict,Depends(get_seller_access_token)],      # now as we have token, now we can take the token and then add it to our blacklist
):
    jti_access_token=token_data["jti"]
    await add_jti_to_blacklist(jti=jti_access_token)

    return { "detail " : " successfully Logged out"}
    


@router.post("/testToken")
async def login__user(request,service:ServiceDepSeller):
     ans= await service.token("root@root.root","root")
     return ans



@router.get("/dashboard")
async def get_dashboard(
    token : Annotated[str,Depends(oauth2_scheme_seller)],
    session: SessionDep
):
    data  =  decode_access_token(token=token)

    if data is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid access token"
        )

    print(data , "#################    Data #################3")
    
    seller = await session.get(Seller,data["user"]["id"])
    return seller