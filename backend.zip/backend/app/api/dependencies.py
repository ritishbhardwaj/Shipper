from typing import Annotated

from fastapi import Depends, HTTPException,status
# from sqlalchemy import UUID
from uuid import UUID
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models import DeliveryPartner, Seller
from app.database.redis import is_jti_blacklisted
from app.database.session import get_session 
from app.services.shipment import ShipmentService
from app.services.seller import SellerService
from app.core.security import oauth2_scheme_seller,oauth2_scheme_delivery_partner
from app.utils import decode_access_token
from app.services.deliver_partner import DeliverPartnerService
from app.services.shipment_event import ShipmentEventService


# Asynchronous database session dep annotation
SessionDep = Annotated[AsyncSession, Depends(get_session)]


#Access token dependency
async def _get_access_token(token :str):
    data  = decode_access_token(token=token)

    if data is None or await is_jti_blacklisted(data["jti"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid access token"
        )
    
    return data

# seller access token
async def get_seller_access_token(token: Annotated[str,Depends(oauth2_scheme_seller)]):
    return await _get_access_token(token=token)


# delivery partner access token
async def get_delivery_partner_access_token(token: Annotated[str,Depends(oauth2_scheme_delivery_partner)]):
    return await _get_access_token(token=token)
    


#Logged in seller
async def get_current_seller(token_data:Annotated[dict,Depends(get_seller_access_token)],
                       session: SessionDep):
    try:
        seller = await session.get(Seller,UUID(token_data["user"]["id"]))

        if seller is None :
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Not Authorised"
            )

        return seller
    except Exception as e:
        raise e



#Logged in delivery partner
async def get_current_delivery_partner(token_data:Annotated[dict,Depends(get_delivery_partner_access_token)],
                       session: SessionDep):
    try:
        partner = await session.get(DeliveryPartner,UUID(token_data["user"]["id"]))
        
        if partner is None :
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Not Authorised"
            )
        return partner
    except Exception as e:
        raise e


# Shipment service dep
def get_shipment_service(session: SessionDep):
    return ShipmentService(
                        session,
                        DeliverPartnerService(session),    # this means we are returning the instance of the object. or we are creating the object/
                        ShipmentEventService(session)
    )


'''
obj= ShipmentService(session)
return obj


so when Annotated type is called through the function parameter then
it will return the object of the class.
'''


# Seller service dep
def get_seller_service(session: SessionDep):
    return SellerService(session)    # this means we are returning the instance of the object. or we are creating the object/


#delivery partner service dep
def get_deliver_partner_service(session: SessionDep):
    return DeliverPartnerService(session)


# Shipment service dep annotation
ServiceDep = Annotated[
    ShipmentService,
    Depends(get_shipment_service),
]

# Seller service dep annotation
ServiceDepSeller = Annotated[
    SellerService,
    Depends(get_seller_service),
]


#Seller dep [ here we are getting the seller details as per it's token_data]
SellerDep=Annotated[
    Seller,
    Depends(get_current_seller)
]


DeliveryPartnerDep=Annotated[
    DeliveryPartner,
    Depends(get_current_delivery_partner)
]


#deliver partner service depenmdency
DeliverPartnerServiceDep=Annotated[
    DeliverPartnerService,
    Depends(get_deliver_partner_service)    
]