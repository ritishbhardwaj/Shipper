from redis.asyncio import Redis

from app.config import db_settings


#creating connection with the REDIS
_conn_token_blacklist = Redis(host=db_settings.REDIS_HOST,
      port=db_settings.REDIS_PORT,
      db=0)    # using 0 index for redis



async def add_jti_to_blacklist(jti:str):
    await _conn_token_blacklist.set(jti,"blacklisted")

async def is_jti_blacklisted(jti:str):
    return  await _conn_token_blacklist.exists(jti)

